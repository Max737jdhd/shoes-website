

let clickme = document.querySelector(".product");
console.log(clickme);

clickme.addEventListener("click",()=>{
  productdetail.style.display="flex"
});

alert("hii");
